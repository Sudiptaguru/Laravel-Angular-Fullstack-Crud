<?php

namespace App;
use DB;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    function getEmployee()
    {
        $data=DB::table('employee')->get();
        // dd($data);
        return $data;
    }
    function addEmployee($data)
    {
        DB::table('employee')->insert($data);
        // dd($data);
    }
}
