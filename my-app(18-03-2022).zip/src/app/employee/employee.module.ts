export class Employee
{
    name:any;
    age:any;
    salary:any;
}