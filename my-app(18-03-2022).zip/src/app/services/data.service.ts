import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http' 
import { Employee } from '../employee/employee.module';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  constructor(
    private httpClient:HttpClient
  ) { }
  getData()
  {
    return this.httpClient.get('http://localhost/test_blog/public/api/employee');
  }
  insertData(data: Employee)
  {
    return this.httpClient.post('http://localhost/test_blog/public/api/addemployee', data);
  }
  deleteData(id: string)
  {
    return this.httpClient.delete('http://localhost/test_blog/public/api/delete/'+id);
  }
  getEmployeeById(id: string)
  {
    return this.httpClient.get('http://localhost/test_blog/public/api/edit/'+id);
  }
}
